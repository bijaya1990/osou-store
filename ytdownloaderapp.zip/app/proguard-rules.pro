# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.kts.

# Google Mobile Ads
-keep class com.google.android.gms.ads.** { *; }

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.ytdownloader.app.**$$serializer { *; }
-keepclassmembers class com.ytdownloader.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.ytdownloader.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}
