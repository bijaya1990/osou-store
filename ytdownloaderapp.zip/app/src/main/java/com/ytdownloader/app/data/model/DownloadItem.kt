package com.ytdownloader.app.data.model

import kotlinx.serialization.Serializable

/**
 * A completed (or in-progress) download persisted to local history and shown in
 * "Recent Downloads" (Home) and "My Downloads".
 */
@Serializable
data class DownloadItem(
    val id: String,
    val title: String,
    val thumbnailUrl: String,
    val qualityLabel: String,
    val fileSizeBytes: Long,
    val filePath: String,
    val mimeType: String,
    val downloadedAtMillis: Long
)
