package com.ytdownloader.app.util

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.ytdownloader.app.data.model.DownloadItem
import java.io.File

object FileUtils {

    /** Resolves a downloaded file into a shareable/openable content [Uri], regardless of which API level saved it. */
    fun uriFor(context: Context, download: DownloadItem): Uri =
        if (download.filePath.startsWith("content://")) {
            Uri.parse(download.filePath)
        } else {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(download.filePath))
        }

    fun deleteFile(context: Context, download: DownloadItem): Boolean =
        if (download.filePath.startsWith("content://")) {
            runCatching { context.contentResolver.delete(Uri.parse(download.filePath), null, null) > 0 }
                .getOrDefault(false)
        } else {
            runCatching { File(download.filePath).delete() }.getOrDefault(false)
        }
}
