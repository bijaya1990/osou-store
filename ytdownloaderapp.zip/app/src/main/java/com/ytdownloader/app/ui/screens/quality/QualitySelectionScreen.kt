package com.ytdownloader.app.ui.screens.quality

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.ytdownloader.app.ads.AdManager
import com.ytdownloader.app.data.model.QualityType
import com.ytdownloader.app.data.model.VideoInfo
import com.ytdownloader.app.data.model.VideoQuality
import com.ytdownloader.app.service.DownloadForegroundService
import com.ytdownloader.app.ui.AppViewModel
import com.ytdownloader.app.ui.components.PremiumCard
import com.ytdownloader.app.ui.components.PremiumScaffold
import com.ytdownloader.app.util.FormatUtils
import com.ytdownloader.app.util.findActivity

@Composable
fun QualitySelectionScreen(
    viewModel: AppViewModel,
    onNavigateToProgress: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context.findActivity()
    val videoInfo by viewModel.currentVideoInfo.collectAsStateWithLifecycle()

    PremiumScaffold(title = "Select Quality", onBack = onBack) { padding ->
        val info = videoInfo
        if (info == null) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("No video loaded", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            return@PremiumScaffold
        }

        val videoQualities = info.availableQualities
            .filter { it.type == QualityType.VIDEO }
            .sortedByDescending { it.resolutionHeight }
        val audioQualities = info.availableQualities.filter { it.type == QualityType.AUDIO }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(vertical = 20.dp)
        ) {
            item { VideoHeader(info) }

            item {
                Text(
                    text = "Video Quality",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            items(videoQualities, key = { it.label }) { quality ->
                QualityRow(quality) {
                    handleQualitySelected(context, activity, viewModel, info, quality, onNavigateToProgress)
                }
            }

            if (audioQualities.isNotEmpty()) {
                item {
                    Text(
                        text = "Audio Only",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                items(audioQualities, key = { it.label }) { quality ->
                    QualityRow(quality) {
                        handleQualitySelected(context, activity, viewModel, info, quality, onNavigateToProgress)
                    }
                }
            }
        }
    }
}

private fun handleQualitySelected(
    context: Context,
    activity: Activity?,
    viewModel: AppViewModel,
    videoInfo: VideoInfo,
    quality: VideoQuality,
    onNavigateToProgress: () -> Unit
) {
    viewModel.selectQuality(quality)

    fun beginDownload() {
        DownloadForegroundService.start(context, videoInfo, quality)
        onNavigateToProgress()
    }

    if (quality.requiresAd && activity != null) {
        AdManager.showRewardedInterstitialAd(activity) { beginDownload() }
    } else {
        // 480p/360p/144p and MP3 never require an ad; also never block if there's no Activity to show one against.
        beginDownload()
    }
}

@Composable
private fun VideoHeader(info: VideoInfo) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        AsyncImage(
            model = info.thumbnailUrl,
            contentDescription = info.title,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = info.title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = FormatUtils.formatDuration(info.durationSeconds),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun QualityRow(quality: VideoQuality, onClick: () -> Unit) {
    PremiumCard(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (quality.type == QualityType.AUDIO) Icons.Filled.MusicNote else Icons.Filled.Movie,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = quality.label,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = FormatUtils.formatFileSize(quality.estimatedSizeBytes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (quality.requiresAd) {
                    Spacer(Modifier.height(6.dp))
                    HdAdBadge()
                }
            }
            Icon(
                imageVector = Icons.Filled.Download,
                contentDescription = "Download ${quality.label}",
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun HdAdBadge() {
    Surface(
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = "HD - Watch ad to unlock",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.bodySmall,
            fontSize = 10.sp
        )
    }
}
