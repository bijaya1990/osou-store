package com.ytdownloader.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ytdownloader.app.ui.AppViewModel
import com.ytdownloader.app.ui.screens.downloads.MyDownloadsScreen
import com.ytdownloader.app.ui.screens.home.HomeScreen
import com.ytdownloader.app.ui.screens.progress.DownloadProgressScreen
import com.ytdownloader.app.ui.screens.quality.QualitySelectionScreen
import com.ytdownloader.app.ui.screens.settings.SettingsScreen

private const val TRANSITION_DURATION_MS = 260

@Composable
fun AppNavGraph(navController: NavHostController = rememberNavController()) {
    val appViewModel: AppViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        enterTransition = {
            fadeIn(tween(TRANSITION_DURATION_MS)) + slideInHorizontally(tween(TRANSITION_DURATION_MS)) { it / 8 }
        },
        exitTransition = { fadeOut(tween(TRANSITION_DURATION_MS)) },
        popEnterTransition = { fadeIn(tween(TRANSITION_DURATION_MS)) },
        popExitTransition = {
            fadeOut(tween(TRANSITION_DURATION_MS)) + slideOutHorizontally(tween(TRANSITION_DURATION_MS)) { it / 8 }
        }
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = appViewModel,
                onNavigateToQuality = { navController.navigate(Screen.Quality.route) },
                onNavigateToDownloads = { navController.navigate(Screen.Downloads.route) },
                onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
            )
        }
        composable(Screen.Quality.route) {
            QualitySelectionScreen(
                viewModel = appViewModel,
                onNavigateToProgress = { navController.navigate(Screen.Progress.route) },
                onBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Progress.route) {
            DownloadProgressScreen(
                viewModel = appViewModel,
                onDone = { navController.popBackStack(Screen.Home.route, false) }
            )
        }
        composable(Screen.Downloads.route) {
            MyDownloadsScreen(
                viewModel = appViewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = appViewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
