package com.ytdownloader.app.data.downloader

import com.ytdownloader.app.data.model.DownloadProgress
import com.ytdownloader.app.data.model.DownloadStatus
import com.ytdownloader.app.data.model.VideoInfo
import com.ytdownloader.app.data.model.VideoQuality
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Application-scoped holder for the single in-flight download's live state. Driven by
 * [com.ytdownloader.app.service.DownloadForegroundService] so the download (and its progress)
 * survives the Progress screen being backgrounded; the UI simply observes [progress].
 */
object DownloadEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var activeJob: Job? = null

    private val _progress = MutableStateFlow(DownloadProgress())
    val progress: StateFlow<DownloadProgress> = _progress.asStateFlow()

    private val _activeVideo = MutableStateFlow<VideoInfo?>(null)
    val activeVideo: StateFlow<VideoInfo?> = _activeVideo.asStateFlow()

    private val _activeQuality = MutableStateFlow<VideoQuality?>(null)
    val activeQuality: StateFlow<VideoQuality?> = _activeQuality.asStateFlow()

    fun start(
        downloaderManager: DownloaderManager,
        videoInfo: VideoInfo,
        quality: VideoQuality,
        onFinished: (DownloadProgress) -> Unit
    ) {
        activeJob?.cancel()
        _activeVideo.value = videoInfo
        _activeQuality.value = quality
        _progress.value = DownloadProgress(status = DownloadStatus.QUEUED)

        activeJob = scope.launch {
            try {
                downloaderManager.downloadVideo(videoInfo, quality).collect { update ->
                    _progress.value = update
                    if (update.status == DownloadStatus.COMPLETED || update.status == DownloadStatus.FAILED) {
                        onFinished(update)
                    }
                }
            } catch (cancellation: CancellationException) {
                _progress.value = _progress.value.copy(status = DownloadStatus.CANCELLED)
                throw cancellation
            } catch (error: Exception) {
                val failed = _progress.value.copy(status = DownloadStatus.FAILED, errorMessage = error.message)
                _progress.value = failed
                onFinished(failed)
            }
        }
    }

    fun cancel() {
        activeJob?.cancel()
        _progress.value = _progress.value.copy(status = DownloadStatus.CANCELLED)
    }

    fun reset() {
        activeJob?.cancel()
        _progress.value = DownloadProgress()
        _activeVideo.value = null
        _activeQuality.value = null
    }
}
