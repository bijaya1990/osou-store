package com.ytdownloader.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.ytdownloader.app.data.preferences.dataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class AppSettings(
    val defaultQuality: String = "720p",
    val saveLocation: String = "Downloads",
    val darkMode: Boolean = true
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val DEFAULT_QUALITY = stringPreferencesKey("default_quality")
        val SAVE_LOCATION = stringPreferencesKey("save_location")
        val DARK_MODE = booleanPreferencesKey("dark_mode")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            defaultQuality = prefs[Keys.DEFAULT_QUALITY] ?: "720p",
            saveLocation = prefs[Keys.SAVE_LOCATION] ?: "Downloads",
            darkMode = prefs[Keys.DARK_MODE] ?: true
        )
    }

    suspend fun setDefaultQuality(quality: String) {
        context.dataStore.edit { it[Keys.DEFAULT_QUALITY] = quality }
    }

    suspend fun setSaveLocation(location: String) {
        context.dataStore.edit { it[Keys.SAVE_LOCATION] = location }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_MODE] = enabled }
    }
}
