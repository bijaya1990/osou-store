package com.ytdownloader.app.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Serializable
enum class QualityType { VIDEO, AUDIO }

/**
 * A single downloadable rendition of a video (e.g. "1080p" video or "MP3" audio).
 * [streamUrl] is populated by the extraction layer and is null until resolved.
 */
@Parcelize
@Serializable
data class VideoQuality(
    val label: String,
    val resolutionHeight: Int,
    val type: QualityType,
    val estimatedSizeBytes: Long,
    val requiresAd: Boolean,
    val streamUrl: String? = null
) : Parcelable
