package com.ytdownloader.app

import android.app.Application
import com.ytdownloader.app.ads.AdManager
import com.ytdownloader.app.util.NotificationHelper

class YtDownloaderApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AdManager.initialize(this)
        NotificationHelper.createChannels(this)
    }
}
