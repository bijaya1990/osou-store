package com.ytdownloader.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.ytdownloader.app.data.model.DownloadItem
import com.ytdownloader.app.data.preferences.dataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Persists download history (thumbnail, title, quality, size, file location) locally so it
 * survives process death. Backed by DataStore Preferences with a JSON-encoded list, which keeps
 * the project dependency-light (no Room/KSP) while still giving real persistence.
 */
class DownloadsRepository(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }
    private val downloadsKey = stringPreferencesKey("downloads_json")

    val downloads: Flow<List<DownloadItem>> = context.dataStore.data.map { prefs ->
        decode(prefs[downloadsKey])
    }

    suspend fun addDownload(item: DownloadItem) {
        context.dataStore.edit { prefs ->
            val updated = listOf(item) + decode(prefs[downloadsKey])
            prefs[downloadsKey] = json.encodeToString(updated)
        }
    }

    suspend fun deleteDownload(id: String) {
        context.dataStore.edit { prefs ->
            val updated = decode(prefs[downloadsKey]).filterNot { it.id == id }
            prefs[downloadsKey] = json.encodeToString(updated)
        }
    }

    private fun decode(raw: String?): List<DownloadItem> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching { json.decodeFromString<List<DownloadItem>>(raw) }.getOrDefault(emptyList())
    }
}
