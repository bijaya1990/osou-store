package com.ytdownloader.app.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

/**
 * Central place for AdMob setup and the rewarded-interstitial gate used to unlock HD (720p/1080p)
 * downloads. Production ad unit IDs are wired in directly per the project brief; a real test
 * device ID is registered via [RequestConfiguration] so development builds never serve live ads.
 */
object AdManager {

    const val BANNER_AD_UNIT_ID = "ca-app-pub-5327551236542725/4289426889"
    const val NATIVE_AD_UNIT_ID = "ca-app-pub-5327551236542725/5291517366"
    private const val REWARDED_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-5327551236542725/6715711453"
    private const val TEST_DEVICE_ID = "4aaf3294-0b68-4ac6-a3ee-d615f82465cf"

    private const val TAG = "AdManager"

    private var rewardedInterstitialAd: RewardedInterstitialAd? = null
    private var isLoadingRewardedAd = false
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return
        initialized = true

        MobileAds.setRequestConfiguration(
            RequestConfiguration.Builder()
                .setTestDeviceIds(listOf(TEST_DEVICE_ID))
                .build()
        )

        MobileAds.initialize(context) {
            Log.d(TAG, "Mobile Ads SDK initialized")
        }

        loadRewardedInterstitialAd(context)
    }

    fun loadRewardedInterstitialAd(context: Context) {
        if (isLoadingRewardedAd || rewardedInterstitialAd != null) return
        isLoadingRewardedAd = true

        RewardedInterstitialAd.load(
            context,
            REWARDED_INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    rewardedInterstitialAd = ad
                    isLoadingRewardedAd = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Rewarded interstitial failed to load: ${error.message}")
                    rewardedInterstitialAd = null
                    isLoadingRewardedAd = false
                }
            }
        )
    }

    /**
     * Shows the rewarded interstitial before an HD (720p/1080p) download starts.
     *
     * [onUnlocked] fires exactly once: after the ad is dismissed, if it fails to show, or
     * immediately when no ad is loaded yet — an HD download must never be blocked by ads.
     */
    fun showRewardedInterstitialAd(activity: Activity, onUnlocked: () -> Unit) {
        val ad = rewardedInterstitialAd
        if (ad == null) {
            Log.d(TAG, "No rewarded interstitial ready — allowing download without an ad")
            loadRewardedInterstitialAd(activity)
            onUnlocked()
            return
        }

        var unlockedCalled = false
        fun unlockOnce() {
            if (!unlockedCalled) {
                unlockedCalled = true
                onUnlocked()
            }
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedInterstitialAd = null
                loadRewardedInterstitialAd(activity)
                unlockOnce()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "Rewarded interstitial failed to show: ${adError.message}")
                rewardedInterstitialAd = null
                loadRewardedInterstitialAd(activity)
                unlockOnce()
            }
        }

        ad.show(activity) {
            // Reward granted callback. The actual unlock is deliberately deferred to
            // onAdDismissedFullScreenContent so the download only starts once the ad
            // experience has fully completed, as required.
        }
    }
}
