package com.ytdownloader.app.util

object YoutubeUrlUtils {

    private val VIDEO_ID_PATTERNS = listOf(
        Regex("(?:youtube\\.com/watch\\?v=)([\\w-]{11})"),
        Regex("(?:youtu\\.be/)([\\w-]{11})"),
        Regex("(?:youtube\\.com/shorts/)([\\w-]{11})"),
        Regex("(?:youtube\\.com/embed/)([\\w-]{11})")
    )

    fun extractVideoId(url: String): String? {
        for (pattern in VIDEO_ID_PATTERNS) {
            pattern.find(url)?.let { return it.groupValues[1] }
        }
        return null
    }

    fun isValidYoutubeUrl(url: String): Boolean = extractVideoId(url) != null

    fun thumbnailUrlFor(videoId: String): String = "https://img.youtube.com/vi/$videoId/hqdefault.jpg"
}
