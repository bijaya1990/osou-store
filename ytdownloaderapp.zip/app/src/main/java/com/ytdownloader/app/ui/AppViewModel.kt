package com.ytdownloader.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ytdownloader.app.data.downloader.DownloaderManager
import com.ytdownloader.app.data.downloader.YtDownloaderManagerImpl
import com.ytdownloader.app.data.model.DownloadItem
import com.ytdownloader.app.data.model.VideoInfo
import com.ytdownloader.app.data.model.VideoQuality
import com.ytdownloader.app.data.repository.AppSettings
import com.ytdownloader.app.data.repository.DownloadsRepository
import com.ytdownloader.app.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Single shared ViewModel backing every screen so fetched video info / selected quality / history / settings stay in sync. */
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val downloaderManager: DownloaderManager = YtDownloaderManagerImpl(application)
    private val downloadsRepository = DownloadsRepository(application)
    private val settingsRepository = SettingsRepository(application)

    val downloads: StateFlow<List<DownloadItem>> = downloadsRepository.downloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _currentVideoInfo = MutableStateFlow<VideoInfo?>(null)
    val currentVideoInfo: StateFlow<VideoInfo?> = _currentVideoInfo.asStateFlow()

    private val _selectedQuality = MutableStateFlow<VideoQuality?>(null)
    val selectedQuality: StateFlow<VideoQuality?> = _selectedQuality.asStateFlow()

    private val _isFetching = MutableStateFlow(false)
    val isFetching: StateFlow<Boolean> = _isFetching.asStateFlow()

    private val _fetchError = MutableStateFlow<String?>(null)
    val fetchError: StateFlow<String?> = _fetchError.asStateFlow()

    fun fetchVideoInfo(url: String, onSuccess: () -> Unit) {
        if (_isFetching.value) return
        viewModelScope.launch {
            _isFetching.value = true
            _fetchError.value = null
            downloaderManager.fetchVideoInfo(url)
                .onSuccess { info ->
                    _currentVideoInfo.value = info
                    _selectedQuality.value = null
                    _isFetching.value = false
                    onSuccess()
                }
                .onFailure { error ->
                    _fetchError.value = error.message ?: "Couldn't fetch video info"
                    _isFetching.value = false
                }
        }
    }

    fun clearFetchError() {
        _fetchError.value = null
    }

    fun selectQuality(quality: VideoQuality) {
        _selectedQuality.value = quality
    }

    fun deleteDownload(id: String) {
        viewModelScope.launch { downloadsRepository.deleteDownload(id) }
    }

    fun setDefaultQuality(quality: String) {
        viewModelScope.launch { settingsRepository.setDefaultQuality(quality) }
    }

    fun setSaveLocation(location: String) {
        viewModelScope.launch { settingsRepository.setSaveLocation(location) }
    }

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setDarkMode(enabled) }
    }
}
