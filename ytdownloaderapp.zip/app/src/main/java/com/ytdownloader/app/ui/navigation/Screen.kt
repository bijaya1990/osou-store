package com.ytdownloader.app.ui.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Quality : Screen("quality")
    data object Progress : Screen("progress")
    data object Downloads : Screen("downloads")
    data object Settings : Screen("settings")
}
