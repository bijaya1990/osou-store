package com.ytdownloader.app.ui.screens.progress

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ytdownloader.app.data.downloader.DownloadEngine
import com.ytdownloader.app.data.model.DownloadStatus
import com.ytdownloader.app.ui.AppViewModel
import com.ytdownloader.app.ui.components.CircularDownloadProgress
import com.ytdownloader.app.ui.components.PremiumScaffold
import com.ytdownloader.app.ui.theme.ErrorRed
import com.ytdownloader.app.ui.theme.SuccessGreen
import com.ytdownloader.app.util.FormatUtils

/** No ads on this screen per spec — the user is mid-download and shouldn't be interrupted. */
@Composable
fun DownloadProgressScreen(
    viewModel: AppViewModel,
    onDone: () -> Unit
) {
    val progress by DownloadEngine.progress.collectAsStateWithLifecycle()
    val activeVideo by DownloadEngine.activeVideo.collectAsStateWithLifecycle()
    val activeQuality by DownloadEngine.activeQuality.collectAsStateWithLifecycle()

    PremiumScaffold(title = "Downloading", showBannerAd = false) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            activeVideo?.let { info ->
                Text(
                    text = info.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
                activeQuality?.let { quality ->
                    Text(
                        text = quality.label,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(28.dp))
            }

            CircularDownloadProgress(percentage = progress.percentage)

            Spacer(Modifier.height(32.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatColumn(label = "Speed", value = FormatUtils.formatSpeed(progress.speedBytesPerSecond))
                StatColumn(label = "ETA", value = FormatUtils.formatEta(progress.etaSeconds))
                StatColumn(
                    label = "Size",
                    value = "${FormatUtils.formatFileSize(progress.downloadedBytes)} / ${FormatUtils.formatFileSize(progress.totalBytes)}"
                )
            }

            Spacer(Modifier.height(40.dp))

            when (progress.status) {
                DownloadStatus.COMPLETED -> {
                    Text("Download complete", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(16.dp))
                    PrimaryActionButton(text = "Done") {
                        DownloadEngine.reset()
                        onDone()
                    }
                }

                DownloadStatus.FAILED -> {
                    Text(
                        text = progress.errorMessage ?: "Download failed",
                        color = ErrorRed,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    PrimaryActionButton(text = "Close") {
                        DownloadEngine.reset()
                        onDone()
                    }
                }

                DownloadStatus.CANCELLED -> {
                    Text(
                        "Download cancelled",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(16.dp))
                    PrimaryActionButton(text = "Close") {
                        DownloadEngine.reset()
                        onDone()
                    }
                }

                DownloadStatus.QUEUED, DownloadStatus.DOWNLOADING -> {
                    OutlinedButton(
                        onClick = { DownloadEngine.cancel() },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedButtonDefaults.outlinedButtonColors(contentColor = ErrorRed)
                    ) {
                        Text("Cancel", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatColumn(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(2.dp))
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PrimaryActionButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.Black
        )
    ) {
        Text(text, fontWeight = FontWeight.Bold)
    }
}
