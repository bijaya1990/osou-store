package com.ytdownloader.app.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper

/** Unwraps Compose's [Context] (often a ContextWrapper) down to the hosting Activity, if any. */
tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
