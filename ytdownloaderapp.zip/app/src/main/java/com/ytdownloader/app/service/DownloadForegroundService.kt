package com.ytdownloader.app.service

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Parcelable
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.ytdownloader.app.data.downloader.DownloadEngine
import com.ytdownloader.app.data.downloader.YtDownloaderManagerImpl
import com.ytdownloader.app.data.model.DownloadItem
import com.ytdownloader.app.data.model.DownloadStatus
import com.ytdownloader.app.data.model.QualityType
import com.ytdownloader.app.data.model.VideoInfo
import com.ytdownloader.app.data.model.VideoQuality
import com.ytdownloader.app.data.repository.DownloadsRepository
import com.ytdownloader.app.util.NotificationHelper
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Drives [DownloadEngine] as a foreground service so a download keeps running (and stays
 * visible via an ongoing notification) even if the user backgrounds the app. A single collector
 * on [DownloadEngine.progress] both maintains the notification and reacts to terminal states
 * (persist to history, show a completion/failure notification, stop itself).
 */
class DownloadForegroundService : LifecycleService() {

    private lateinit var downloaderManager: YtDownloaderManagerImpl
    private lateinit var downloadsRepository: DownloadsRepository

    override fun onCreate() {
        super.onCreate()
        downloaderManager = YtDownloaderManagerImpl(applicationContext)
        downloadsRepository = DownloadsRepository(applicationContext)
        NotificationHelper.createChannels(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        val videoInfo = intent?.parcelableExtraCompat<VideoInfo>(EXTRA_VIDEO_INFO)
        val quality = intent?.parcelableExtraCompat<VideoQuality>(EXTRA_QUALITY)
        if (videoInfo == null || quality == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(
            NotificationHelper.DOWNLOAD_NOTIFICATION_ID,
            NotificationHelper.buildProgressNotification(this, videoInfo.title, 0)
        )

        DownloadEngine.start(downloaderManager, videoInfo, quality) { /* handled below */ }

        lifecycleScope.launch {
            DownloadEngine.progress.collect { progress ->
                when (progress.status) {
                    DownloadStatus.DOWNLOADING, DownloadStatus.QUEUED -> {
                        startForeground(
                            NotificationHelper.DOWNLOAD_NOTIFICATION_ID,
                            NotificationHelper.buildProgressNotification(this@DownloadForegroundService, videoInfo.title, progress.percentage)
                        )
                    }

                    DownloadStatus.COMPLETED -> {
                        downloadsRepository.addDownload(
                            DownloadItem(
                                id = UUID.randomUUID().toString(),
                                title = videoInfo.title,
                                thumbnailUrl = videoInfo.thumbnailUrl,
                                qualityLabel = quality.label,
                                fileSizeBytes = progress.totalBytes,
                                filePath = progress.savedFileIdentifier.orEmpty(),
                                mimeType = if (quality.type == QualityType.AUDIO) "audio/mpeg" else "video/mp4",
                                downloadedAtMillis = System.currentTimeMillis()
                            )
                        )
                        NotificationHelper.showCompletionNotification(applicationContext, videoInfo.title)
                        stopForegroundCompat()
                        stopSelf()
                    }

                    DownloadStatus.FAILED -> {
                        NotificationHelper.showFailureNotification(applicationContext, videoInfo.title)
                        stopForegroundCompat()
                        stopSelf()
                    }

                    DownloadStatus.CANCELLED -> {
                        stopForegroundCompat()
                        stopSelf()
                    }
                }
            }
        }

        return START_NOT_STICKY
    }

    private fun stopForegroundCompat() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
    }

    companion object {
        private const val EXTRA_VIDEO_INFO = "extra_video_info"
        private const val EXTRA_QUALITY = "extra_quality"

        fun start(context: Context, videoInfo: VideoInfo, quality: VideoQuality) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                putExtra(EXTRA_VIDEO_INFO, videoInfo)
                putExtra(EXTRA_QUALITY, quality)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        /** Prefer [DownloadEngine.cancel] — the service observes the resulting CANCELLED status and stops itself. */
        fun stop(context: Context) {
            context.stopService(Intent(context, DownloadForegroundService::class.java))
        }
    }
}

private inline fun <reified T : Parcelable> Intent.parcelableExtraCompat(key: String): T? =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        getParcelableExtra(key, T::class.java)
    } else {
        @Suppress("DEPRECATION")
        getParcelableExtra(key)
    }
