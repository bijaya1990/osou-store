package com.ytdownloader.app.data.downloader

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.ytdownloader.app.data.model.DownloadProgress
import com.ytdownloader.app.data.model.DownloadStatus
import com.ytdownloader.app.data.model.QualityType
import com.ytdownloader.app.data.model.VideoInfo
import com.ytdownloader.app.data.model.VideoQuality
import com.ytdownloader.app.util.YoutubeUrlUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.OutputStream
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Default [DownloaderManager] implementation.
 *
 * [extractVideoInfo] is a clearly marked TODO: it currently fabricates plausible metadata so the
 * rest of the app (UI, ad gating, the download pipeline, notifications, history) is fully
 * exercisable end-to-end. Everything below it (network streaming to a file with live progress,
 * writing into public storage) is real, functioning code that will keep working unchanged once a
 * real extractor supplies genuine stream URLs.
 */
class YtDownloaderManagerImpl(
    private val appContext: Context
) : DownloaderManager {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override suspend fun fetchVideoInfo(url: String): Result<VideoInfo> = runCatching {
        require(url.isNotBlank()) { "Please paste a valid video URL" }
        extractVideoInfo(url)
    }

    // ---------------------------------------------------------------------------------------
    // TODO: YOUTUBE EXTRACTION — replace this entire function body.
    //
    // Integrate a real extraction library here (e.g. NewPipeExtractor, youtubedl-android, a
    // yt-dlp binding, or a backend you control) and return a [VideoInfo] built from real data:
    //   - real video title
    //   - real thumbnail URL
    //   - real duration in seconds
    //   - ONLY the qualities genuinely encoded for this video, each with a working direct
    //     stream URL (progressive or muxed) and an accurate file size in bytes
    //   - an "MP3" / QualityType.AUDIO entry if audio-only extraction is supported
    //
    // Everything downstream (downloadVideo below, the UI, ad gating) already expects exactly
    // this shape, so no other code needs to change when this is wired up for real.
    // ---------------------------------------------------------------------------------------
    private suspend fun extractVideoInfo(url: String): VideoInfo {
        delay(900) // simulates real extraction network latency

        val videoId = YoutubeUrlUtils.extractVideoId(url)
        val seed = (videoId ?: url.trim()).hashCode()

        val allHeights = listOf(1080, 720, 480, 360, 144)
        // Not every real video has every rendition encoded — simulate that by deterministically
        // capping the max quality available for this particular URL.
        val maxHeightIndex = when (Math.floorMod(seed, 4)) {
            0 -> 0 // up to 1080p
            1 -> 1 // up to 720p
            2 -> 2 // up to 480p
            else -> 3 // up to 360p
        }
        val availableHeights = allHeights.drop(maxHeightIndex)

        val durationSeconds = 180L + Math.floorMod(seed, 900)
        val bitrateKbpsByHeight = mapOf(
            1080 to 4500,
            720 to 2500,
            480 to 1200,
            360 to 700,
            144 to 250
        )

        val videoQualities = availableHeights.map { height ->
            val bitrateKbps = bitrateKbpsByHeight.getValue(height)
            VideoQuality(
                label = "${height}p",
                resolutionHeight = height,
                type = QualityType.VIDEO,
                estimatedSizeBytes = estimateSizeBytes(bitrateKbps, durationSeconds),
                requiresAd = height >= 720,
                streamUrl = SAMPLE_STREAM_URL
            )
        }

        val audioQuality = VideoQuality(
            label = "MP3",
            resolutionHeight = 0,
            type = QualityType.AUDIO,
            estimatedSizeBytes = estimateSizeBytes(AUDIO_BITRATE_KBPS, durationSeconds),
            requiresAd = false,
            streamUrl = SAMPLE_STREAM_URL
        )

        return VideoInfo(
            sourceUrl = url,
            title = "Video ${videoId ?: (Math.abs(seed) % 100000)}",
            thumbnailUrl = videoId?.let { YoutubeUrlUtils.thumbnailUrlFor(it) } ?: SAMPLE_THUMBNAIL_URL,
            durationSeconds = durationSeconds,
            availableQualities = videoQualities + audioQuality
        )
    }
    // --------------------------------- END TODO SECTION --------------------------------------

    override fun downloadVideo(
        videoInfo: VideoInfo,
        quality: VideoQuality
    ): Flow<DownloadProgress> = flow {
        emit(DownloadProgress(status = DownloadStatus.DOWNLOADING))

        val streamUrl = quality.streamUrl ?: error("No stream URL available for ${quality.label}")
        val request = Request.Builder().url(streamUrl).build()

        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Download failed: HTTP ${response.code}")
            val body = response.body ?: error("Empty response body")

            val totalBytes = body.contentLength().let { if (it > 0) it else quality.estimatedSizeBytes }
            val fileExtension = if (quality.type == QualityType.AUDIO) "mp3" else "mp4"
            val fileName = "${sanitizeFileName(videoInfo.title)}_${quality.label}.$fileExtension"

            val target = openDownloadTarget(fileName, quality.type)
            var downloadedBytes = 0L
            var lastEmitTimeMs = System.currentTimeMillis()
            var lastEmitBytes = 0L

            target.outputStream.use { out ->
                body.byteStream().use { input ->
                    val buffer = ByteArray(DOWNLOAD_BUFFER_SIZE)
                    while (true) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        out.write(buffer, 0, read)
                        downloadedBytes += read

                        val now = System.currentTimeMillis()
                        val elapsedMs = now - lastEmitTimeMs
                        if (elapsedMs >= PROGRESS_EMIT_INTERVAL_MS) {
                            val bytesSinceLast = downloadedBytes - lastEmitBytes
                            val speed = if (elapsedMs > 0) bytesSinceLast * 1000L / elapsedMs else 0L
                            val remaining = (totalBytes - downloadedBytes).coerceAtLeast(0)
                            val eta = if (speed > 0) remaining / speed else 0L
                            val percentage = if (totalBytes > 0) {
                                ((downloadedBytes * 100.0) / totalBytes).roundToInt().coerceIn(0, 100)
                            } else 0

                            emit(
                                DownloadProgress(
                                    percentage = percentage,
                                    downloadedBytes = downloadedBytes,
                                    totalBytes = totalBytes,
                                    speedBytesPerSecond = speed,
                                    etaSeconds = eta,
                                    status = DownloadStatus.DOWNLOADING
                                )
                            )
                            lastEmitTimeMs = now
                            lastEmitBytes = downloadedBytes
                        }
                    }
                }
            }
            target.finalize()

            emit(
                DownloadProgress(
                    percentage = 100,
                    downloadedBytes = downloadedBytes,
                    totalBytes = if (totalBytes > 0) totalBytes else downloadedBytes,
                    status = DownloadStatus.COMPLETED,
                    savedFileIdentifier = target.identifier
                )
            )
        }
    }.flowOn(Dispatchers.IO)

    private fun estimateSizeBytes(bitrateKbps: Int, durationSeconds: Long): Long =
        (bitrateKbps * 1000L / 8L) * durationSeconds

    private fun sanitizeFileName(rawName: String): String =
        rawName.replace(Regex("[^a-zA-Z0-9_\\- ]"), "").trim().ifBlank { "video" }.take(60)

    /** Opens an output stream in the public Downloads collection, working across all supported API levels. */
    private fun openDownloadTarget(fileName: String, type: QualityType): DownloadTarget {
        val mimeType = if (type == QualityType.AUDIO) "audio/mpeg" else "video/mp4"

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = appContext.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val itemUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Failed to create MediaStore entry")
            val stream = resolver.openOutputStream(itemUri) ?: error("Failed to open output stream")
            DownloadTarget(
                outputStream = stream,
                identifier = itemUri.toString(),
                finalize = {
                    resolver.update(
                        itemUri,
                        ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) },
                        null,
                        null
                    )
                }
            )
        } else {
            @Suppress("DEPRECATION")
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val file = File(downloadsDir, fileName)
            DownloadTarget(
                outputStream = file.outputStream(),
                identifier = file.absolutePath,
                finalize = {}
            )
        }
    }

    private data class DownloadTarget(
        val outputStream: OutputStream,
        val identifier: String,
        val finalize: () -> Unit
    )

    private companion object {
        const val DOWNLOAD_BUFFER_SIZE = 8 * 1024
        const val PROGRESS_EMIT_INTERVAL_MS = 250L
        const val AUDIO_BITRATE_KBPS = 128

        // Public domain sample stream used only until real extraction is wired in (see TODO above).
        const val SAMPLE_STREAM_URL =
            "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
        const val SAMPLE_THUMBNAIL_URL =
            "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerBlazes.jpg"
    }
}
