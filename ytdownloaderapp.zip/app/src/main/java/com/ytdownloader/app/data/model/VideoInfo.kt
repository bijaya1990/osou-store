package com.ytdownloader.app.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
data class VideoInfo(
    val sourceUrl: String,
    val title: String,
    val thumbnailUrl: String,
    val durationSeconds: Long,
    val availableQualities: List<VideoQuality>
) : Parcelable
