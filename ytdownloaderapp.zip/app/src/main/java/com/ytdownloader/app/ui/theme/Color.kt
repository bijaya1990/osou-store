package com.ytdownloader.app.ui.theme

import androidx.compose.ui.graphics.Color

// Dark premium palette (spec)
val DarkBackground = Color(0xFF0A0E27)
val DarkSurfaceCard = Color(0xFF1A1F3A)
val AccentCyan = Color(0xFF00D4FF)
val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFFB0B8D4)

val SuccessGreen = Color(0xFF00E676)
val ErrorRed = Color(0xFFFF5252)
val WarningAmber = Color(0xFFFFB300)

// Light complement, used only if the user disables dark mode from Settings.
val LightBackground = Color(0xFFF4F6FB)
val LightSurfaceCard = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF0A0E27)
val TextSecondaryLight = Color(0xFF5B6382)
