package com.ytdownloader.app.ui.components

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.ytdownloader.app.ads.AdManager

private const val CARD_BACKGROUND_HEX = "#1A1F3A"
private const val ACCENT_HEX = "#00D4FF"
private const val SECONDARY_TEXT_HEX = "#B0B8D4"

/** Fixed banner ad shown at the bottom of every screen. */
@Composable
fun BannerAdView(modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = AdManager.BANNER_AD_UNIT_ID
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}

/** Native ad styled as a list row, blended into the Recent Downloads list on the Home screen. */
@Composable
fun NativeAdCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(Unit) {
        val adLoader = AdLoader.Builder(context, AdManager.NATIVE_AD_UNIT_ID)
            .forNativeAd { ad -> nativeAd = ad }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    nativeAd = null
                }
            })
            .build()
        adLoader.loadAd(AdRequest.Builder().build())

        onDispose { nativeAd?.destroy() }
    }

    val ad = nativeAd ?: return

    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { ctx -> buildNativeAdView(ctx, ad) }
    )
}

private fun buildNativeAdView(context: Context, nativeAd: NativeAd): NativeAdView {
    val density = context.resources.displayMetrics.density
    fun dp(value: Int) = (value * density).toInt()

    val adView = NativeAdView(context).apply {
        background = GradientDrawable().apply {
            setColor(android.graphics.Color.parseColor(CARD_BACKGROUND_HEX))
            cornerRadius = dp(12).toFloat()
        }
        setPadding(dp(16), dp(16), dp(16), dp(16))
    }

    val outer = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

    val row = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    val iconView = ImageView(context).apply {
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(12) }
        scaleType = ImageView.ScaleType.CENTER_CROP
    }

    val textColumn = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    }

    val adBadge = TextView(context).apply {
        text = "Ad"
        setTextColor(android.graphics.Color.parseColor(ACCENT_HEX))
        textSize = 10f
        setPadding(dp(6), dp(2), dp(6), dp(2))
        background = GradientDrawable().apply {
            setColor(android.graphics.Color.TRANSPARENT)
            setStroke(dp(1), android.graphics.Color.parseColor(ACCENT_HEX))
            cornerRadius = dp(4).toFloat()
        }
    }

    val headline = TextView(context).apply {
        setTextColor(android.graphics.Color.WHITE)
        textSize = 15f
        setTypeface(typeface, Typeface.BOLD)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setPadding(0, dp(4), 0, dp(2))
    }

    val body = TextView(context).apply {
        setTextColor(android.graphics.Color.parseColor(SECONDARY_TEXT_HEX))
        textSize = 12f
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }

    textColumn.addView(adBadge)
    textColumn.addView(headline)
    textColumn.addView(body)

    row.addView(iconView)
    row.addView(textColumn)

    val cta = Button(context, null, android.R.attr.borderlessButtonStyle).apply {
        setTextColor(android.graphics.Color.BLACK)
        background = GradientDrawable().apply {
            setColor(android.graphics.Color.parseColor(ACCENT_HEX))
            cornerRadius = dp(8).toFloat()
        }
        textSize = 12f
        isAllCaps = false
        setPadding(dp(16), dp(8), dp(16), dp(8))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(12)
            gravity = Gravity.END
        }
    }

    outer.addView(row)
    outer.addView(cta)
    adView.addView(
        outer,
        ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    )

    adView.headlineView = headline
    adView.bodyView = body
    adView.iconView = iconView
    adView.callToActionView = cta

    headline.text = nativeAd.headline
    body.text = nativeAd.body
    body.visibility = if (nativeAd.body.isNullOrBlank()) TextView.GONE else TextView.VISIBLE
    nativeAd.icon?.let { iconView.setImageDrawable(it.drawable) }
    iconView.visibility = if (nativeAd.icon == null) ImageView.GONE else ImageView.VISIBLE
    cta.text = nativeAd.callToAction
    cta.visibility = if (nativeAd.callToAction.isNullOrBlank()) Button.GONE else Button.VISIBLE

    adView.setNativeAd(nativeAd)

    return adView
}
