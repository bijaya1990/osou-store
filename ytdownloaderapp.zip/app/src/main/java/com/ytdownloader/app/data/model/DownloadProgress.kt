package com.ytdownloader.app.data.model

enum class DownloadStatus { QUEUED, DOWNLOADING, COMPLETED, FAILED, CANCELLED }

data class DownloadProgress(
    val percentage: Int = 0,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val speedBytesPerSecond: Long = 0L,
    val etaSeconds: Long = 0L,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val savedFileIdentifier: String? = null,
    val errorMessage: String? = null
)
