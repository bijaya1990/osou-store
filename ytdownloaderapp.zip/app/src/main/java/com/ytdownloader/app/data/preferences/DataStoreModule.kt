package com.ytdownloader.app.data.preferences

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore

val Context.dataStore by preferencesDataStore(name = "yt_downloader_prefs")
