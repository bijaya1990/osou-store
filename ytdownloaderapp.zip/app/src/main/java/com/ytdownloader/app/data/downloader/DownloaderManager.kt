package com.ytdownloader.app.data.downloader

import com.ytdownloader.app.data.model.DownloadProgress
import com.ytdownloader.app.data.model.VideoInfo
import com.ytdownloader.app.data.model.VideoQuality
import kotlinx.coroutines.flow.Flow

/**
 * Clean boundary between the UI/domain layer and the actual YouTube extraction + download
 * mechanics. Swap [YtDownloaderManagerImpl] internals (specifically [YtDownloaderManagerImpl]'s
 * extraction routine) for a real extractor without touching any call site.
 */
interface DownloaderManager {

    /** Resolves a pasted URL into a title, thumbnail, duration and the qualities available for it. */
    suspend fun fetchVideoInfo(url: String): Result<VideoInfo>

    /** Streams [quality] of [videoInfo] to public storage, emitting progress as it goes. */
    fun downloadVideo(videoInfo: VideoInfo, quality: VideoQuality): Flow<DownloadProgress>
}
